# API Object Model (Conceptual)

```json
{
  "product": {
    "id": "prod-001",
    "name": "AI Diagnostic Tool",
    "class": "MDR IIa",
    "is_high_risk_ai": true,
    "templates": [
      {
        "template_id": "RMF_v1",
        "status": "approved",
        "last_updated": "2026-01-10"
      }
    ],
    "scores": {
      "MDR": 72,
      "GDPR": 65,
      "AI_ACT": 58
    }
  }
}
```
