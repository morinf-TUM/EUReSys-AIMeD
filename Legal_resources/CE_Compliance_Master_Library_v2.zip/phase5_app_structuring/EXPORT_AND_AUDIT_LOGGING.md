# Export & Audit Logging

- Every export must:
  - Embed the Per-Template Disclaimer
  - Stamp version, date, and user
  - Record in immutable audit log

## Log Fields
| Field | Description |
|-------|-------------|
| user_id | Exporting user |
| template_id | Template reference |
| version | Template version |
| timestamp | UTC |
| product_id | Target product |
| hash | File checksum |

Purpose:
- Demonstrate controlled documentation
- Support internal audits
- Prevent misuse claims
