# Versioning & Update Model

- Use semantic versioning for templates: MAJOR.MINOR.PATCH
- MAJOR: regulatory restructuring or breaking changes
- MINOR: added sections or regulatory updates
- PATCH: clarifications or typo fixes

## Deprecation Rules
- Mark deprecated templates as read-only
- Provide migration notes to successor templates
- Maintain audit access to historical versions

## Regulatory Updates
- Track:
  - MDR amendments & MDCG guidance
  - EDPB guidelines
  - AI Act delegated acts & harmonized standards
- Each update triggers:
  - Impact assessment
  - Template delta
  - Version bump
