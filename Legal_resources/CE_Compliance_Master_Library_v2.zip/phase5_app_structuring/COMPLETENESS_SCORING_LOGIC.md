# Completeness Scoring Logic

Each regulation is represented as a set of obligations.

For a given product:

1. Identify applicable obligations (by class, function, data use, AI status)
2. Map obligations to required templates
3. Score each template:
   - 0 = Missing
   - 1 = Draft
   - 2 = Approved

## Example (MDR)

| Obligation | Template | Status | Score |
|------------|----------|--------|-------|
| Annex I | RMF | Approved | 2 |
| Annex II | Tech Doc | Draft | 1 |
| Annex III | PMS Plan | Missing | 0 |

Aggregate per regulation and overall readiness.

## Output
- MDR Readiness %
- GDPR Readiness %
- AI Act Readiness %
- Global Compliance Index
