# Tagging Taxonomy

## Regulatory Tags
- MDR: Annex I, II, III, XIV
- GDPR: Art. 5, 6, 30, 32, 35, 28, 12–23
- AI_ACT: Art. 9–15, 61

## Lifecycle Tags
- Concept
- Design
- Development
- Verification
- Release
- Post-Market
- Decommissioning

## Role Tags
- QA/RA
- Clinical
- Software
- ML/Data
- Security
- DPO
- Management

## Risk Domain Tags
- Clinical Safety
- Software Safety
- Cybersecurity
- Data Protection
- Bias & Fairness
- Operational
