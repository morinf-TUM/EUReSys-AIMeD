# Template Metadata Schema

Each template in the library should be described using the following schema.

```json
{
  "id": "string-unique",
  "name": "Human-readable title",
  "version": "v1.0.0",
  "category": "MDR | GDPR | AI_ACT | CROSS",
  "regulations": ["MDR", "GDPR", "AI_ACT"],
  "legal_anchors": [
    {"framework": "MDR", "reference": "Annex I, Clause 17"},
    {"framework": "AI_ACT", "reference": "Article 15"}
  ],
  "standards": ["ISO 14971", "IEC 62304"],
  "lifecycle_stage": ["Design", "Development", "Post-Market"],
  "roles": ["QA", "Regulatory", "ML", "DPO"],
  "prerequisites": ["Risk Management File"],
  "outputs": ["Audit-ready document"],
  "risk_domains": ["Clinical", "Cybersecurity", "Data Protection"],
  "last_reviewed": "YYYY-MM-DD",
  "status": "draft | active | deprecated"
}
```
